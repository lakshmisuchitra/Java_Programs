package learning;
import java.io.*;
import java.util.*;
public class IfChecking {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int N=sc.nextInt();
		if(N%2==0)
		{
			System.out.println("Not  Weird:");
		}
		else if(N%2!=0)
		{
			System.out.println("Weird:");
		}
		if(N>=2||N<=5)
		{
			System.out.println("Not Weird:");
		}
		else if(N>=6||N<=20)
		{
			System.out.println("Weird:");
		}
		
		
	}

}
