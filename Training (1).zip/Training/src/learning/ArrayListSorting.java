package learning;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
public class ArrayListSorting {
	public static void main(String args[])
	{
		ArrayList<Integer> al=new ArrayList<>();
		al.add(1);
		al.add(0);
		al.add(9);
		al.add(8);
		al.add(7);
		Collections.sort(al);
		System.out.println("The Sorted ArrayList IS:"+al);
		ArrayList<String> al1=new ArrayList<>();
		al1.add("Apple");
		al1.add("Guava");
		al1.add("Banana");
		al1.add("Mango");
		al1.add("Custard Apple");
		Collections.sort(al1);
		System.out.println("Sorted String Array List Is:"+al1);
		ArrayList<Character> al2=new ArrayList<>();
		al2.add('c');
		al2.add('b');
		al2.add('a');
		Collections.sort(al2);
		System.out.println("Sorted Character ArrayList:"+al2);
	}

}
