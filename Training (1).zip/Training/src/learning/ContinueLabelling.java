package learning;
import java.io.*;
public class ContinueLabelling {
	public static void main(String args[])
	{
		outer: for(int i=0;i<10;i++)
		{
			for(int j=0;j<10;j++)
			{
				if(j==7)
				{
					continue outer;
				}
				System.out.println("J value is:"+j);
			}
		}
	}

}
