package learning;
import java.io.*;
import java.lang.NullPointerException;
public class NullValue {
	public static void main(String args[]) throws NullPointerException
	{
  /*	Object obj=Null;
		Object obj1=NULL;*/
		Object obj2=null;
		System.out.println(obj2);
	}

}
