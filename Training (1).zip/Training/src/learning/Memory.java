package learning;
import java.io.*;
public class Memory {
	public static void main(String args[]) throws IOException
	{
	//	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int i;
		int j=1;
		int k=1;
		//j=br.read();
		System.out.println("The j value is:"+j);
		//k=br.read();
		System.out.println("The k value is:"+k);
		i=j*k;
		System.out.println("The Multilplied result value is:"+i);
	}

}
