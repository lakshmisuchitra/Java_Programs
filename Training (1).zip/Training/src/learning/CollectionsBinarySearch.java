package learning;
import java.io.*;
import java.util.Collections;
import java.util.ArrayList;
public class CollectionsBinarySearch{
	public static void main(String args[])
	{
		ArrayList<Integer> al=new ArrayList<>();
		al.add(1);
		al.add(2);
		al.add(93);
		al.add(108);
		al.add(48);
		al.add(18);
		Collections.sort(al);
		System.out.println("The Sorted ArrayList Is:"+al);
		int key=108;
		int result=Collections.binarySearch(al, key);
		if(result>=0)
		{
			System.out.println(key+"The Key Found At Index:"+result);
		}
		else
		{
			System.out.println(key+"The Key Found At No Where In The ArrayList:");
		}
		key=50;
		result=Collections.binarySearch(al, key);
		if(result>=0)
		{
			System.out.println(key+"The Key Found At Index:"+result);
		}
		else
		{
			System.out.println(key+"The Key Found At No Where In The ArrayList: ");
		}
		}
	
}
