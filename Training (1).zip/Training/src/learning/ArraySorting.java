package learning;
import java.io.*;
import java.util.Arrays;
public class ArraySorting {
	public static void main(String args[])
	{
		int arr[]= {48,108,33,11,9,18};
		Arrays.sort(arr);
		System.out.println("The Sorted Array Is:%s"+Arrays.toString(arr));
	}

}
