package learning;
import java.io.*;
public class EqualityCheck {
	public static void main(String args[])
	{
		int i=1;
		int i1=1;
		if(i==i1)
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
		String s="AMMA";
		String s1="AMMA";
		if(s.equals(s1))
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
	}

}
