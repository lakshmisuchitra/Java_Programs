package learning;
import java.io.*;
public class BreakingLabel {
public static void main(String args[])
{
	boolean value=true;
	first:{
	second:{
	third:{
		System.out.println("Before Breaking a label:");
	if(value)
	{
		break second;
	}
	}
	System.out.println("This won't execute:");
}
	System.out.println("The Final value of these cases were:"+value);
}
}
}
