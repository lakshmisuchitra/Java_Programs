package learning;
import java.io.*;
import java.util.*;
public class SwappingWithOutTemp {
	public static void main(String args[]) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
	    System.out.println("The Entered Values For Variables Were:"+a+b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("The Swapped Values After Swapping:"+a+b);
	}

}
