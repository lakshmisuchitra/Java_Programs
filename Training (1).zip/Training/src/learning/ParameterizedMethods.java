package learning;
import java.io.*;
public class ParameterizedMethods {
public int tripleAverage(int a,int b,int c)
{
	int d;
	d=(a+b+c)/3;
	System.out.println("The Average is:"+d);
	return 0;
}
public static void main(String args[])
{
	ParameterizedMethods pm=new ParameterizedMethods();
	int average=pm.tripleAverage(10, 20, 30);
	}
}
