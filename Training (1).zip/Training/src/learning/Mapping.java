package learning;
import java.io.*;
import java.util.*;
public class Mapping {
public static void main(String args[])
{
	Map<Integer,String> employeelist=new HashMap<>();
	System.out.println(employeelist.put(100,"Ramu"));
	System.out.println(employeelist.put(101,"Krishna"));
	System.out.println(employeelist.put(102,"Shiva"));
	System.out.println(employeelist.put(103,"Maheshwara"));
	System.out.println(employeelist.size());
	System.out.println(employeelist.get(103));
	System.out.println(employeelist.keySet());
	System.out.println(employeelist.values());
	System.out.println(employeelist.containsKey(102));
	System.out.println(employeelist.containsValue("Ramu"));
	System.out.println(employeelist.containsValue("Krishna"));
}
}
