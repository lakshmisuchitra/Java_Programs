package learning;
import java.io.*;
import java.util.*;
public class QuickSort
{
	int partition(int arr[],int low,int high)
	{
		int pivot=arr[high]; //taking last or highest  value as pivot value for sorting
		int  i=low-1; //index of the least or starting element
		for(int j=low;j<high;j++)
		{
			if(j<=pivot)
			{
				i++;
				int temp=arr[i]; //swapping i & j variables
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
			int temp=arr[i+1];
			arr[i+1]=pivot; //swapping i+1 & pivot or arr[high]
			pivot=temp;
			return i+1;
}
	void sort(int arr[],int low,int high)  //method for sorting
	{
		if(low<high)
		{
			int pi=partition(arr, low, high);
			sort(arr,low,pi-1); //least values should be placed before pivot
			sort(arr,pi+1,high); //highest values should be placed after pivot
		}
	}
	static void printArray(int arr[]) //method to print array of size of n elements
	{
		int n=arr.length-1;
		for(int i=0;i<=n;i++)
		{
			System.out.println(arr[i]+" ");
			System.out.println();
		}
		
	}
	public static void main(String args[])
	{
		int arr[]= {1,7,8,9,5};
		int n=arr.length-1;
		QuickSort qs=new QuickSort();
		qs.sort(arr, 0, n-1);
		System.out.println("The Sorted Array Is:"+arr);
		printArray(arr);
	}
}