package learning;
import java.io.*;
public class Conversion {
	public static void main(String args[])
	{
		System.out.print("Y"+"O");
	    System.out.print('L');
	    System.out.print('O');
	}

}
