package learning;
import java.io.*;
enum colours{
	Red,Green,Blue
}
public class Colour
{
	public static void main(String args[])
	{
		colours c=colours.Red;
		colours c1=colours.Green;
		colours c2=colours.Blue;
		System.out.println(c);
		System.out.println(c1);
		System.out.println(c2);
	}
}
