package learning;
import java.io.*;
import java.util.Collections;
import java.util.ArrayList;
public class DescendingOrderForArrayList{
	public static void main(String args[])
	{
		ArrayList<Integer> al=new ArrayList<>();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		Collections.sort(al,Collections.reverseOrder());
		System.out.println("The Reversed ArrayList Is:"+al);
		ArrayList<Character> al1=new ArrayList<>();
		al1.add('a');
		al1.add('b');
		al1.add('c');
		al1.add('d');
		Collections.sort(al1,Collections.reverseOrder());
		System.out.println("The Reversed Order Of Character ArrayList Is:"+al1);
		ArrayList<String> al2=new ArrayList<>();
		al2.add("Mango");
		al2.add("Apple");
		al2.add("Banana");
		al2.add("CustardApple");
		Collections.sort(al2,Collections.reverseOrder());
		System.out.println("The Sorted ArrayList Of String Is:"+al2);
				
		
	}
}