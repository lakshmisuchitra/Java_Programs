package learning;
import java.io.*;
import java.util.Arrays;
public class BinarySearch{
	public static void main(String args[])
	{
		int num[]= {30,15,5,48,108};
		Arrays.parallelSort(num);
		int key=48;
		int result=Arrays.binarySearch(num, key);
		if(result>=0)
		{
		System.out.println(key+"Found At Index:"+result);
		}
		else
		{
			System.out.println(key+"Not Found At Any Index:");
		}
		key=22;
		result=Arrays.binarySearch(num, key);
		if(result>=0)
		{
			System.out.println(key+"Found At Index:"+result);
		}
		else
		{
			System.out.println(key+"Not Found At Any Index:");
		}
	}
}
