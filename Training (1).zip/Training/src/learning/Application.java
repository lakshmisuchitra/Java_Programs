package learning;
import java.io.*;
public class Application {
	public int multiply()
	{
		int r;
		int m1=1,m2=1;
		r=m1*m2;
		System.out.println("The Result of multiplication is:"+r);
		return 0;
		}
public static void main(String args[])
{
	Application app=new Application();
	app.multiply();
}

}
