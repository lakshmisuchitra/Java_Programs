package learning;
import java.io.*;
public class SubString {
	public static void main(String args[])
	{
		String s="APPA";
		String s1=s.substring(0,3);
		System.out.println("The SubString is:"+s1);
	}

}
