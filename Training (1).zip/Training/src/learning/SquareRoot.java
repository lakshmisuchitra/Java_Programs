package learning;
import java.io.*;
import java.util.*;
import java.lang.StrictMath;
public class SquareRoot
{
	public static void main(String args[])
	{
		double d=144.0;
		int root=(int)StrictMath.sqrt(d);
		System.out.println("The Casted Root Is:"+root);
		double square=StrictMath.getExponent(d);
		System.out.println("The Square Value Is:"+square);
	}
}