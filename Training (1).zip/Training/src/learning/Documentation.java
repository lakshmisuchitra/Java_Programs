package learning;
import java.io.*;
/*@author learning
 * <h1> average calculation by sum of two numbers</h1>
 * */
 
public class Documentation  {
	public static void main(String args[]) 
	{
		int a,b,c;
		a=10;
		b=22;
		c=a+b/2;
		System.out.println(c);
		
	}
	

}
