package learning;
import java.io.*;
public class Apppending {
	public static void main(String args[])
	{
		StringBuffer sb=new StringBuffer("Apple");
		sb.append('s');
		System.out.println(sb);
		sb.append(1);
		System.out.println(sb);
		sb.append('&');
		System.out.println(sb);
		
	}

}
