package learning;
import java.io.*;
import java.lang.*;
public class InstanceOperation
{
	public static void main(String args[]) throws NullPointerException
	{
		Integer i=null;
		Integer j=10;
		System.out.println(i instanceof Integer );
		System.out.println(j instanceof Integer);
	}
}
