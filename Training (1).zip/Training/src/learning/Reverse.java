package learning;
import java.io.*;
public class Reverse {
	public static void main(String args[])
	{
		StringBuffer sb2=new StringBuffer("RAM&ROM");
		sb2.reverse();
		System.out.println(sb2);
		sb2.reverse();
		System.out.println(sb2);
		sb2.delete(0, 4);
		System.out.println(sb2);
		sb2.deleteCharAt(1);
		System.out.println(sb2);
		sb2.replace(1, 6, "AM&Ro");
		System.out.println(sb2);
	}

}
