package learning;
import java.io.*;
import java.lang.Math;
import java.util.*;
public class Cosine {
	public static void main(String args[])
	{
		double degree=90.0;
		double radians=Math.toRadians(degree);
		double cosinevalue=Math.cos(radians);
		System.out.println("Degree("+degree+") cosine value is:"+cosinevalue);
	}

}
