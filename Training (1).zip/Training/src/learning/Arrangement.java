package learning;
import java.io.*;
import java.util.*;
public class Arrangement {
public static void main(String args[])
{
	int num[]= {0,1,2,3,4};
	System.out.println("The size of the array is:"+num.length);
	
	
	
}
}
