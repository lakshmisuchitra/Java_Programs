package learning;
import java.io.*;
import java.util.Collections;
import java.util.Arrays;
public class DescendingOrderSorting
{
	public static void main(String args[])
	{
		Integer num[]= {11,9,18,48,40,108};
		//we use wrapper classes as Collections.reverseOrder doesn't support primitive data types
		Arrays.sort(num,Collections.reverseOrder());
		System.out.println("The Numerical Arrayn In DescendingOrder Is:%s"+Arrays.toString(num));
		
	}
}