package learning;
import java.io.*;
public class Doing {
	public static void main(String args[])
	{
		do {
			int i=1;
	        int j=i++;      //i+1;
			System.out.println(j);
		}
		while(true);

	}

}
