package learning;
import java.io.*;
import java.util.*;
public class Pali
{
	public static void main(String args[])
	{
		String str;
		String pal="";
		Scanner sc=new Scanner(System.in);
		str=sc.nextLine();
		int length=str.length();
		for(int i=length-1;i>=0;i--)
		{
			pal=pal+str.charAt(i);
		}
		if(str.equals(pal))
		{
			System.out.println("The string is a palindrome:"+str);
		}
		else
		{
			System.out.println("The string is not a palindrome:"+str);
	
		}
	}
}
