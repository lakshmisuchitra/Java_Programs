package learning;
import java.io.*;
public class Booleanvalue {
	public static void main(String args[]) throws IOException
	{
		boolean b=true;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter Boolean Value:"+b);
	    if(b==true)
		{
			System.out.println("Hello World:");
		}
		else
		{
			System.out.println("Hai All World:");
		}
	}

}
