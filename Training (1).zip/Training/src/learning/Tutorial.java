package learning;
import java.io.*;
public class Tutorial {
	public static void main(String args[])
	{
		Funny f=new Funny();
		f.fun(5);
		}
	}
 class Funny
{
	public void fun(int x)
	{
		System.out.println("fun() method called:"+x)
;	}
}
