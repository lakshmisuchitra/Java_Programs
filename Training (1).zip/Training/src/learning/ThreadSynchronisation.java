package learning;
import java.io.*;
import java.lang.*;
class Tables
{
	public synchronized void printTable(int n)
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println(n*i);
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException ie)
			{
				ie.printStackTrace();
			}
		}
	}
}
class MyThread extends Thread
{
	Tables t;
	MyThread(Tables t)
	{
		this.t=t;
	}
	public void run() {
		t.printTable(5);
		}
}
class MyThread1 extends Thread
{
	Tables t;
	MyThread1(Tables t)
	{
		this.t=t;
	}
	public void run() 
	{
		t.printTable(7);
	}
}
public class ThreadSynchronisation
{
	public static void main(String args[])
	{
		Tables tab=new Tables();
		MyThread mth=new MyThread(tab);
		MyThread1 mth1=new MyThread1(tab);
		mth.start();
		mth1.start();
	}
}