package learning;
import java.io.*;
import java.util.Collections;
import java.util.LinkedList;
public class LinkedListSorting {
	public static void main(String args[])
	{
		LinkedList<Integer> ll=new LinkedList<>();
		ll.add(8);
		ll.add(9);
		ll.add(7);
		ll.add(3);
		ll.add(2);
		ll.add(1);
		Collections.sort(ll);
		System.out.println("The Sorted LinkedList Is:"+ll);
		LinkedList<Character> ll1=new LinkedList<>();
		ll1.add('e');
		ll1.add('d');
		ll1.add('c');
		ll1.add('b');
		ll1.add('a');
		Collections.sort(ll1);
		System.out.println("The Sorted Linked List Of Characters Is:"+ll1);
		LinkedList<String> ll2=new LinkedList<>();
		ll2.add("Lion");
		ll2.add("Elephant");
		ll2.add("Monkey");
		ll2.add("Tiger");
		Collections.sort(ll2);
		System.out.println("The Sorted LinkedList Of Strings:"+ll2);
		}

}
