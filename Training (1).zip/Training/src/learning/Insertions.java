package learning;
import java.io.*;
public class Insertions {
	public static void main(String args[])
	{
		StringBuffer SB=new StringBuffer("BANANA");
		SB.insert(6, 's');
		System.out.println(SB);
		SB.insert(0, 1);
		System.out.println(SB);
		char[] cha= {'f','r','u','i','t'};
		SB.insert(0,cha);
		System.out.println(SB);
				
		}
	}


