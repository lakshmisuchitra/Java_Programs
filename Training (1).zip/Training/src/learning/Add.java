package learning;
import java.io.*;
public class Add {
	public static void main(String args[])
	{
		int x,y,z;
		x=1;
		y=2;
		z=x+y;
		System.out.println("The Total Of Sum Is:"+z);
		
	}

}
