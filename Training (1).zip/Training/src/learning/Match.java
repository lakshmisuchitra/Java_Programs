package learning;
import java.io.*;
import java.util.*;
public class Match {
public static void main(String args[])
{
	String str="Akbar_Khan_1236@.txt";
	String str1="Baba_Khan";
	String str2=str1.concat(str);
	System.out.println("The Resulltant String is:"+str2);
	
	
}
}
