package learning;
import java.io.*;
import java.lang.*;
public class NewThreadingTest extends Thread {
	public void run()
	{
		for(int j=1;j<=7;j++)
		{
			System.out.println("Print the Thread value:"+j);
		}
		System.out.println("exit from the thread:");
	}
	public static void main(String args[])
	{
		NewThreadingTest ntt=new NewThreadingTest();
		ntt.run();
	}
	

}
