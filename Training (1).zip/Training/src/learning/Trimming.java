package learning;
import java.io.*;
public class Trimming {
	public static void main(String args[])
	{
		String s=" APPA ";
		s.trim();
		System.out.println("The Trimmed String Is:"+s);
	}

}
