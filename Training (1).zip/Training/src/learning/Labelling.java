package learning;
import java.io.*;
public class Labelling {
	public static void main(String args[])
	{
		outer: for(int i=0;i<10;i++)
		{
			for(int j=0;j<10;j++)
			{
				if(j==3)
				{
					break outer;
				}
				System.out.println("The Value Of J is:"+j);
			}
		}
	}

}
