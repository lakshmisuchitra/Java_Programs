package learning;
import java.io.*;
import java.lang.*;
enum Cities
{
	DELHI,BOMBAY,CALCUTTA;
	private Cities()
	{
		System.out.println("Constructor called for:"+this.toString());
	}
	public void cityInfo()
	{
		System.out.println("India's Best cities:");
	}
}
public class NorthCities
{
	public static void main(String args[])
	{
		Cities ci=Cities.CALCUTTA;
		System.out.println(ci);
		ci.cityInfo();
	}
}
