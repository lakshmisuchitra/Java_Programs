package learning;
import java.io.*;
public class NumericPalindrome {
	public static void main(String args[]) throws IOException
	{
		int num,rev=0,rem,temp;
		//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		num=121;
		System.out.println("Enter The Given Number:"+num);
		temp=num;
		while(num!=0)
		{
			rem=num%10;
			rev=rev*10+rem;
			num/=10; //num=num/10
		}
		if(temp==rev)
		{
			System.out.println("The Number Is A Palindrome:"+temp);
			
		}
		else
		{
			System.out.println("The Number Is Not A Palindrome:"+temp);
		}
	}

}
