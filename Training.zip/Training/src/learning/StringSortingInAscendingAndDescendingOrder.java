package learning;
import java.io.*;
import java.util.Arrays;
import java.util.Collections;
public class StringSortingInAscendingAndDescendingOrder {
public static void main(String args[])
{
	String arr[]= {"Sun","Earth","Moon"};
	Arrays.sort(arr);
	System.out.println("The Sorted String Array Is:\n%s"+Arrays.toString(arr));
    Arrays.sort(arr,Collections.reverseOrder());
    System.out.println("Reversed Order for String Is:\n%s"+Arrays.deepToString(arr));


}
    
    
}
