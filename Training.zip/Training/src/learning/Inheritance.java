package learning;
import java.io.*;
import java.util.*;
 class Fruit
{
int size;
char colourcode;
String taste;
}

public class Inheritance extends Fruit {
	public static void main(String args[])
	{
		Inheritance ih=new Inheritance();
		ih.size=25;
		ih.colourcode='R';
		ih.taste="Sweet";
		System.out.println("THE CHARACTERISTIC FEATURES OF FRUIT WERE AS FOLLOWS:"+ih.size +ih.colourcode +ih.taste);
	}
	}
