package learning;
import java.io.*;
import java.util.*;
public class DataStoring {
	public static void main(String args[])
	{
		Set<String> allbicycles=new LinkedHashSet<>();
		allbicycles.add("BSA");
		allbicycles.add("Lady Bird");
		allbicycles.add("Hero");
		List<String> mybicycles=new ArrayList<>();
		System.out.println(allbicycles.size());
		mybicycles.addAll(allbicycles);
		System.out.println(mybicycles);
	}

}
