package learning;
import java.io.*;
import java.lang.*;

public class ThreadStart extends Thread {
      public void start()
      {
    	  for(int k=1;k<=9;k++)
    	  {
    		System.out.println("Print this thread:"+k);
    	  }
    	  System.out.println("Exit from thread:");
    	  
    	  
      }
      public static void main(String args[])
      {
    	  ThreadStart ts=new ThreadStart();
    	  ts.start();
      }
	
	
	

}