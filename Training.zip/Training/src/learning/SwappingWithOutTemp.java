package learning;
import java.io.*;
public class SwappingWithOutTemp {
	public static void main(String args[]) throws IOException
	{
		int a;
		int b;
		DataInputStream in=new DataInputStream(System.in);
		a=in.readInt();
		b=in.readInt();
		System.out.println("The Entered Values For Variables Were:"+a+b);
		a=a+b-a;
		b=b+a-b;
		System.out.println("The Swapped Values After Swapping:"+a+b);
	}

}
