package learning;
import java.io.*;
public class Address {
	private String Hno;
	private String street;
	private String city;
	private String state;
	public String getHno() {
		return Hno;
	}
	public void setHno() {
		this.Hno=Hno;
		
	}
	public String getStreet()
	{
		return street;
	}
public void setStreet()
{
	this.street=street;
}
public String getCity()
{ 
	return city;
}
public void setCity() {
	this.city=city;
	}
public String getState() {
	return state;
}
public void setState()
{
	this.state=state;
}
}
