package learning;
import java.io.*;
import java.lang.*;
public class ThreadTest extends Thread {
public void run()
{
			for(int i=1;i<=5;i++)
			{
				System.out.println("Print thread A:"+i);
			}
			System.out.println("Exit from thread A:");
}
	
public static void main(String args[])
{
	ThreadTest tt=new ThreadTest();
	tt.run();
}
}
