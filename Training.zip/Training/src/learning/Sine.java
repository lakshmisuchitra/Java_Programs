package learning;
import java.io.*;
import java.lang.*;
import java.util.*;
public class Sine
{
	public static void main(String args[])
	{
		double degrees=45.0; //initializing double degrees variable as it is a input
		double radians=Math.toRadians(degrees);//degrees converted into Radians using Math.toRadians() method
		double sinevalue=Math.sin(radians);
		System.out.println("sine value of("+degrees+") is:"+sinevalue);
	}
}
