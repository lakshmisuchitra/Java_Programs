package learning;
import java.io.*;
import java.lang.Math;
public class Sequence {
	public static void main(String args[])
	{
		String str="Hello! Welcome To The Beautiful World ";
		CharSequence str2=str.subSequence(0, 9);
		System.out.println(str2);
		
		
	}

}
