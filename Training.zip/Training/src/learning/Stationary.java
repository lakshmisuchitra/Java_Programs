package learning;
import java.io.*;
public class Stationary {
public static int weight1=25;
public static int weight2=30;
public static int weight3=weight1+weight2;
public static void main(String args[])
{
	System.out.println(Stationary.weight3);
}
}
