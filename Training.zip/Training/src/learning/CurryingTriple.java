package learning;
import java.io.*;
import java.util.function.Function;
public class CurryingTriple
{
	public static void main(String args[])
	{
		//BY USING JAVA8 FEATURES AND LAMBDA EXPRESSION FORMAT WE CAN MAKE A FUNCTION CURRY
		Function<Integer,Function<Integer,Function<Integer,Integer>>>
		curryTripleMultiply=p->q->r->p*q*r;
		System.out.println("Multiplication Result Of p,q,r:"+curryTripleMultiply.apply(11).apply(11).apply(11));
	}
}