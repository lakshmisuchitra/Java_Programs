package learning;
import java.io.*;
public class StringFunctions {
	public static void main(String args[])
	{
		String str=new String("abc");
	char c=	str.charAt(2);
		
		System.out.println("The character at particular position in string was:"+c);
	}

}
