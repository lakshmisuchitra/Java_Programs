package learning;
import java.io.*;
import java.lang.*;


public class ThreadActions extends Thread{
	public void run()
	{
		System.out.println("HELLO WORLD");
	
	try
	{
		Thread.sleep(3000);
	}
	catch(InterruptedException IE)
	{
		IE.printStackTrace();
	}
	System.out.println("HAI WORLD");
	}
	public static void main(String args[])
	{
		ThreadActions ta1=new ThreadActions();
		ThreadActions ta2=new ThreadActions();
		ta1.start();
		ta2.start();
		System.out.println(ta1.isAlive());
		System.out.println(ta2.isAlive());
	}
}
