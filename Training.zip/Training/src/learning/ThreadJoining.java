package learning;
import java.io.*;
import java.lang.*;
public class ThreadJoining extends Thread {
	public void run()
	{
		System.out.println("Welcome World:");
	
	try
	{
		Thread.sleep(700);
	}
	catch(InterruptedException IE)
	{
		IE.printStackTrace();
	}
	System.out.println("The World Is Beautiful:");
	}
	public static void main(String args[])
	{
		ThreadJoining tj=new ThreadJoining();
		ThreadJoining tj1=new ThreadJoining();
		tj.start();
		try {
			tj.join();
		}
		catch(InterruptedException IE)
		{
			
		}
		tj1.start();
	}

}
