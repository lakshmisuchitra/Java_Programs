package learning;
import java.io.*;
public class UnderScore {
	public static void main(String args[])
	{
		int _=1;
		int num_number=10;
		System.out.println(_+num_number);
	}
	

}
