package learning;
import java.io.*;
import java.lang.*;
public class NewThreadTest extends Thread  {
	public void run()
	{
		System.out.println("Welcome");
		try
		{
			Thread.sleep(7000);
		}
		catch(InterruptedException IE)
		{
			IE.printStackTrace();
		}
		System.out.println("World");
	}
	public static void main(String args[])
	{
		NewThreadTest ntt=new NewThreadTest();
		NewThreadTest ntt1=new NewThreadTest();
		ntt.start();
		ntt1.start();
		System.out.println(ntt.isAlive());
		System.out.println(ntt1.isAlive());
	}
	

}
