package learning;
import java.io.*;
public class NumericalLabelling
{
	public static void main(String args[])
	{
		outer:for(int i=0;i<3;i++)
		{
			System.out.println("Pass:"+i);
			for(int j=0;j<100;j++)
			{
				if(j==48)
				{
					break outer;
				}
				System.out.println("J value is:"+j);
			}
			System.out.println("This will not get printed:");
		}
	System.out.println("Loops Were completed:");
	}
}

	
