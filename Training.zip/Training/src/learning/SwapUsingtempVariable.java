package learning;
import java.io.*;
public class SwapUsingtempVariable {
	public static void main(String args[])
	{
		int a=1;
		int b=2;
		int temp;
		System.out.println("The Vriable values Before Swapping:"+a+b);
		temp=a;
		a=b;
		b=temp;
		System.out.println("The Swapped variables Were:"+a+b);
	}

}
