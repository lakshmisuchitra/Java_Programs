package learning;
import java.io.*;
import java.util.*;
import java.lang.Math;
public class Tan {
	public static void main(String args[])
	{
		double degree=270.0;
	    double radians=   Math.toRadians(degree);	
	    double tangentvalue=Math.tan(radians);
	    System.out.println("tan("+degree+") is:"+tangentvalue);
	}
}
