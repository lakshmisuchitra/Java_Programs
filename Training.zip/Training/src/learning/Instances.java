package learning;
import java.io.*;
public class Instances {
	int marks1;
	int marks2;
	int marks3;
	public static void main(String args[])
	{
		Instances i=new Instances();
		i.marks1=10;
		i.marks2=20;
		i.marks3=i.marks1+i.marks2;
		System.out.println("The Total Marks Were:"+i.marks3);
	}

}
