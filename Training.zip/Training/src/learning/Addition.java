package learning;
import java.io.*;
import java.util.*;
public class Addition {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int num;
		int digit1,digit2;
		digit1=sc.nextInt();
		digit2=sc.nextInt();
		num=digit1+digit2;
		System.out.println("The ResultantSum is:"+num);
		
	}

}
