package learning;
import java.io.*;
import java.lang.*;

public class ThreadChecking extends Thread
{
	@SuppressWarnings("deprecation")
	public void start() {
	for(int i=1;i<=5;i++)
		{
		if(i==2) {
			yield();
			System.out.println("From First Thread:"+i);
			
		}
System.out.println("Exit from first thread:");			
		}
	
		for(int j=1;j<=6;j++)
	{
		if(j==4)
		{
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("From Second Thread:"+j);
		}
		System.out.println("Exit From Second Thread:");
		}
	
	for(int k=1;k<=7;k++)
	{
		if(k==3)
		{
			stop();
			System.out.println("From Third Thread:"+k);
		}
		System.out.println("Exit From Third Thread:");
	}
	}
	public static void main(String args[])
	{
		ThreadChecking tc=new ThreadChecking();
		tc.start();
	}
	}
	


