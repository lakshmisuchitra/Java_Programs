package learning;
import java.io.*;
import java.lang.*;
public class NullObject {
	private static Object obj;
	public static void main(String args[]) throws NullPointerException
	{
		System.out.println("The value of the object if object class which is a top most class in java:"+obj);
		//default value for a variable is null
	}

}
