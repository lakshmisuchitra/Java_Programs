package learning;
import java.io.*;
public class DataTypes  {
	public static void main(String args[])
	{
		int i=2;
		System.out.println (i);
		char c='e';
		System.out.println(c);
	    float f=1.1f;
	    System.out.println(f);
	    double d=2.22789;
	    System.out.println(d);
	    boolean b=true;
	    System.out.println(b);
	    byte b1=11;
	    System.out.println(b1);
	    short si=33;
	    System.out.println(si);
	    long li=48l;
	    System.out.println(li);
	    String str="ABC";
	    System.out.println(str);
	  

	}
}