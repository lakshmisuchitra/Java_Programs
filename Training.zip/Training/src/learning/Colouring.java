package learning;
import java.io.*;
import java.lang.Enum;
public class Colouring
{
	enum colours
	{
		RED,GREEN,BLUE;
	}
	public static void main(String args[])
	{
		colours arr[]=colours.values();
		for(colours col:arr)
		{
			System.out.println(col+"Indice's are:"+col.ordinal());
		}
		System.out.println(colours.valueOf("RED"));
	}
}
