package learning;
import java.io.*;
public class CityName {
	enum Cities{
		NewDelhi,Mumbai,Kolkata,Chennai,Bengaluru,Hyderabad
	}
	public static void main(String args[])
	{
		Cities c=Cities.Mumbai;
		Cities c1=Cities.Kolkata;
		Cities c2=Cities.Chennai;
		Cities c3=Cities.Hyderabad;
		Cities c4=Cities.Bengaluru;
		Cities c5=Cities.NewDelhi;
		System.out.println("The List Of Cities In India:"+ c+ c1+ c2+ c3+ c4+ c5);
	}

}
