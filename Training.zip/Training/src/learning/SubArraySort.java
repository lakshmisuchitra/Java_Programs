package learning;
import java.io.*;
import java.util.Arrays;
import java.util.Collections;
public class SubArraySort
{
	public static void main(String args[])
	{
		int arr[]= {2,7,5,9,8,6,3,1};
		Arrays.sort(arr,0,3);
		System.out.println("The Sorted SubArray Is:%s"+Arrays.toString(arr));
	}
}
