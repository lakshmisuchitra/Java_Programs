package learning;
import java.io.*;
import java.util.*;
class Student
{
	int rollno;
	String name;
	String address;
	public Student(int rollno,String name,String address)
	{
		this.rollno=rollno;
		this.name=name;
		this.address=address;
	}
	public String toString() //returns string to the main() method
	{
		return this.rollno+" "+this.name+" "+this.address;
	}
}
class SortByRollNo implements Comparator<Student>
{
	public int compare(Student a,Student b)
	{
		return a.rollno-b.rollno;
	}
}
public class ComparatorSort
{
	public static void main(String args[])
	{
		Student arr[]= {new Student(2,"Krishna","Dwaraka"),new Student(3,"Shiva","Kailsha"),new Student(1,"Ramu","Ayodhya")};
		System.out.println("Unsorted Array:");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("Student's Array:"+arr[i]);
		}
		System.out.println("Sorted Array:");
		Arrays.sort(arr,new SortByRollNo());
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("Student's Array:"+arr[i]);
		}
		
		}
}