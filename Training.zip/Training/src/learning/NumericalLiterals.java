package learning;
import java.io.*;
import java.lang.*;
public class NumericalLiterals
{
	public static void main(String args[]) throws java.lang.Exception
	{
		int i=1_00_0;
		System.out.println("Integral Is:"+i);
		short s=1_0;
		System.out.println("ShortIntegral Is:"+s);
		long l=1_00_000_0;
		System.out.println("LongIntegral Is:"+l);
		float f=2.5_0f;
		System.out.println("Float Decimal value Is:"+f);
		double d=2.225_0_00;
		System.out.println("Double Decimal Value Is:"+d);
	}
}
