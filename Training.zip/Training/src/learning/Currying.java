package learning;
import java.io.*;
import java.util.function.Function;
public class Currying
{
	public static void main(String args[])
	{
		//By Using Java8 Features And By Lambda Expression Format We Can Make A Function Currying
		Function<Integer,Function<Integer,Integer>>
		curryAdd=a->b->a+b;
		System.out.println("Add a,b:"+curryAdd.apply(7).apply(7));
		
	}
}