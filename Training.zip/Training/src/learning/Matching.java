package learning;
import java.io.*;
public class Matching {
	public static void main(String args[])
	{
		String s1=new String("AMMA");
		String s2="AMMA";
		if(s1==s2) {
			System.out.println("true and text string matching");
			
		}
		else if(s1.equals(s2))
		{
			System.out.println("String is matching in another way");
		}
	}

}
