package learning;
import java.io.*;
import java.lang.*;
class Testing1 extends Thread
{
	public void run()
	{
		synchronized(this)
		{
			System.out.println(Thread.currentThread().getName()+"Starting:");
			try
			{
				this.wait();
			}
			catch(InterruptedException ie)
			{
				ie.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+"Notified:");
		}
	}
}
class Testing2 extends Thread
{
	Testing1 t1;
	Testing2(Testing1 t1)
	{
		this.t1=t1;
	}
	public void run()
	{
		synchronized(this.t1)
		{
			System.out.println(Thread.currentThread().getName()+"Starting:");
			try
			{
				this.t1.wait();
			}
			catch(InterruptedException ie)
			{
				ie.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+"Notified:");
		}
	}
}
class Testing3 extends Thread
{
	Testing1 t1;
	Testing3(Testing1 t1)
	{
		this.t1=t1;
	}
	public void run()
	{
		synchronized(this.t1)
		{
			System.out.println(Thread.currentThread().getName()+"Starting:");
			this.t1.notifyAll();
			System.out.println(Thread.currentThread().getName()+"Notified:");
		}
	}
}
public class AllNotification
{
	public static void main(String args[]) throws InterruptedException 
	{
		Testing1 t1=new Testing1();
		Testing2 t2=new Testing2(t1);
		Testing3 t3=new Testing3(t1);
		Thread th1=new Thread(t1,"The");
		Thread th2=new Thread(t2,"Program of");
		Thread th3=new Thread(t3,"Notification");
		th1.start();
		th2.start();
		Thread.sleep(900);
		th3.start();
		
	}
}
	
	
