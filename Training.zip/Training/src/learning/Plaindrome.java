package learning;
import java.io.*;
import java.util.*;
public class Plaindrome {
	public static void main(String args[])
	{
		String str="AMMA";
		int length=str.length();
		String rev="";
		for(int i=length-1;i>=0;i--)
		{
			rev=rev+str.charAt(i);
			
		}
		if(rev.equals(str))
		{
			System.out.println("The String is a palindrome:"+rev);
		}
		else
		{
			System.out.println("The String is not a palindrome:"+str);
		}
	}

}
