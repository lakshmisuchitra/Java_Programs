package learning;
import java.io.*;
import java.lang.*;
public class OperationalCheck {
	public static void main(String args[])
	{
		String s=new String("MADAM");
		String s1=new String("MADAM");
		if(s==s1)
		{
			System.out.println(true);
		}
		else if(s.equals(s1))
		{
			System.out.println("Value IS:"+true);
		}
	}

}
