package learning;
import java.io.*;
import java.lang.*;
public class NullException {
	public static void main(String args[]) throws NullPointerException
	{
		Integer a=null; //ASSIGNING NULL TO INTEGER WRAPPER CLASS AUTOBOXING POSSIBLE
		int i=a; /*REASSIGINING NULL TO PRIMITIVE DATA TYPE INT UNBOXING WILL THROW 
		POINTER EXCEPTION*/
		System.out.println(a);
	}

}
