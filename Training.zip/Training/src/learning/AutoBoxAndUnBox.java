package learning;
import java.io.*;
public class AutoBoxAndUnBox {
	/**
	 * @param args
	 */
	public static void main(String args[])
	{
		Integer a=2;
		int sum=a+5;//reverse AutoBoxing Means UnBoxing 
		int b=1;
		Integer c=b+1;//Another way of AutoBoxing i.e conversion of primitive data type to object of wrapper class 
		System.out.println("The Integer Sum Result Is:"+sum);
		System.out.println("The Unboxing Of Integral result Is:"+c);
	}

}
