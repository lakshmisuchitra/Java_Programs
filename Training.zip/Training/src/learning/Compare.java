package learning;
import java.io.*;
import java.util.*;
public class Compare {
	public static void main(String args[])
	{
		String str="AMMA";
		String str1="AMMA";
		if(str.equals(str1))
		{
			System.out.println("Both Strings are same:"+str);
		}
	}

}
