package learning;
import java.io.*;
public class StringHashing {
	public static void main(String args[])
	{
		String str="APPLE";
		System.out.println("The HashCode Of The String;"+str.hashCode());
		
	}

}
