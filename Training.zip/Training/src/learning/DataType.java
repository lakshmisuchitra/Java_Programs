package learning;
import java.io.*;
public class DataType {
	/**
	 * @param args
	 */
	public static void main(String args[])
	{
		byte b=126;
		System.out.println(b);
		b++;
		System.out.println(b);
		b--;
		System.out.println(b);
		b++;
		System.out.println(b);
		b++;
		System.out.println(b);
	}                             //Because Byte Holds Value From -128 to 127

}
