package learning;
import java.io.*;
import java.util.*;
public class OwnBinarySearch
{
	int binarySearch(int arr[],int l,int r,int x)
	{
		if(r>=1)
		{
			int mid=l+(r-1)/2;
			if(arr[mid]==x)
			{
				return mid;
			}
			else if(arr[mid]>x)
			{
				return binarySearch(arr,l,mid-1,x);
			}
			else
			{
				return binarySearch(arr,r,mid+1,x);
			}
			}
		return -1;
	}
	public static void main(String args[])
	{
		OwnBinarySearch obs=new  OwnBinarySearch();
		int arr[]= {1,2,48,108};
		int n=arr.length;
		int x=48;
		int result=obs.binarySearch(arr, 0, n-1, x);
		if(result==-1)
		{
			System.out.println("Element Not Found:");
		}
		else
		{
		System.out.println("Element Found At Index:"+result);
		}
		}
}