package learning;
import java.io.*;
public class Intern {
public static void main(String args[])
{
	StringBuffer sb=new StringBuffer("AMMA");
	int p=sb.length();
	int q=sb.capacity();
	int r=p+q;
	System.out.println("The Sum of length and capacity is r:"+r);
}
}
