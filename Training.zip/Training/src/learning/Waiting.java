package learning;
import java.io.*;
import java.lang.*;
class Test1 extends Thread
{
	public  void run()
	{
		synchronized(this)
		{
			System.out.println(Thread.currentThread().getName()+"start");
			try
			{
				this.wait();
			}
			catch(InterruptedException ie)
{
			ie.printStackTrace();	
				}
			System.out.println(Thread.currentThread().getName()+"notify");
		}
			
	}
}
class Test2 extends Thread
{
	Test1 t1;
	Test2(Test1 t1)
	{
		this.t1=t1;
		}
	public void run() {
		synchronized(this.t1)
		{
			System.out.println(Thread.currentThread().getName()+"start:");
			try
			{
				this.t1.wait();
			}
			catch(InterruptedException ie)
			{
				ie.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+"Notified:");
		}
		
	}
}
class Test3 extends Thread
{
	Test1 t1;
	Test3(Test1 t1)
	{
	    this.t1=t1;
	}
	public void run()
	{
		synchronized(this.t1)
		{
			System.out.println(Thread.currentThread().getName()+"start:");
			t1.notify();
			System.out.println(Thread.currentThread().getName()+"notify:");
			
		}
	}
}
public class Waiting
{
	public static void main(String args[]) throws InterruptedException
	{
		Test1 t1=new Test1();
		Test2 t2=new Test2(t1);
		Test3 t3=new Test3(t1);
		Thread th1=new Thread(t1,"Print");
		Thread th2=new Thread(t2,"print");
		Thread th3=new Thread(t3,"print");
		th1.start();
		th2.start();
		Thread.sleep(100);
		th3.start();
	}
}