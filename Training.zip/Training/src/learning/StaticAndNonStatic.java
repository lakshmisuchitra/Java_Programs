package learning;
import java.io.*;
import java.lang.*;
public class StaticAndNonStatic{
	public static void main(String args[])
	{
		StaticAndNonStatic sans=null;
		sans.staticMethod();
		sans.nonStaticMethod();
	}
	private static void staticMethod()
	{
		System.out.println("This Method is a static method so it will bonded with static Binding so it will not throw an exception:");
		
	}
	private void nonStaticMethod()
	{
		System.out.println("It Will Throw Null Pointer Eception:");
	}
}
